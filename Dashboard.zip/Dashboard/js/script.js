function legend({
                    color,
                    title,
                    tickSize = 6,
                    width = 320,
                    height = 44 + tickSize,
                    marginTop = 18,
                    marginRight = 0,
                    marginBottom = 16 + tickSize,
                    marginLeft = 0,
                    ticks = width / 64,
                    tickFormat,
                    tickValues
                } = {}) {

    const svg = d3.create("svg")
        .attr("width", width)
        .attr("height", height)
        .attr("viewBox", [0, 0, width, height])
        .style("overflow", "visible")
        .style("display", "block");

    let tickAdjust = g => g.selectAll(".tick line").attr("y1", marginTop + marginBottom - height);
    let x;

    // Continuous
    if (color.interpolate) {
        const n = Math.min(color.domain().length, color.range().length);

        x = color.copy().rangeRound(d3.quantize(d3.interpolate(marginLeft, width - marginRight), n));

        svg.append("image")
            .attr("x", marginLeft)
            .attr("y", marginTop)
            .attr("width", width - marginLeft - marginRight)
            .attr("height", height - marginTop - marginBottom)
            .attr("preserveAspectRatio", "none")
            .attr("xlink:href", ramp(color.copy().domain(d3.quantize(d3.interpolate(0, 1), n))).toDataURL());
    }

    // Sequential
    else if (color.interpolator) {
        x = Object.assign(color.copy()
                .interpolator(d3.interpolateRound(marginLeft, width - marginRight)),
            {
                range() {
                    return [marginLeft, width - marginRight];
                }
            });

        svg.append("image")
            .attr("x", marginLeft)
            .attr("y", marginTop)
            .attr("width", width - marginLeft - marginRight)
            .attr("height", height - marginTop - marginBottom)
            .attr("preserveAspectRatio", "none")
            .attr("xlink:href", ramp(color.interpolator()).toDataURL());

        // scaleSequentialQuantile doesn’t implement ticks or tickFormat.
        if (!x.ticks) {
            if (tickValues === undefined) {
                const n = Math.round(ticks + 1);
                tickValues = d3.range(n).map(i => d3.quantile(color.domain(), i / (n - 1)));
            }
            if (typeof tickFormat !== "function") {
                tickFormat = d3.format(tickFormat === undefined ? ",f" : tickFormat);
            }
        }
    }

    // Threshold
    else if (color.invertExtent) {
        const thresholds
            = color.thresholds ? color.thresholds() // scaleQuantize
            : color.quantiles ? color.quantiles() // scaleQuantile
                : color.domain(); // scaleThreshold

        const thresholdFormat
            = tickFormat === undefined ? d => d
            : typeof tickFormat === "string" ? d3.format(tickFormat)
                : tickFormat;

        x = d3.scaleLinear()
            .domain([-1, color.range().length - 1])
            .rangeRound([marginLeft, width - marginRight]);

        svg.append("g")
            .selectAll("rect")
            .data(color.range())
            .join("rect")
            .attr("x", (d, i) => x(i - 1))
            .attr("y", marginTop)
            .attr("width", (d, i) => x(i) - x(i - 1))
            .attr("height", height - marginTop - marginBottom)
            .attr("fill", d => d);

        tickValues = d3.range(thresholds.length);
        tickFormat = i => thresholdFormat(thresholds[i], i);
    }

    // Ordinal
    else {
        x = d3.scaleBand()
            .domain(color.domain())
            .rangeRound([marginLeft, width - marginRight]);

        svg.append("g")
            .selectAll("rect")
            .data(color.domain())
            .join("rect")
            .attr("x", x)
            .attr("y", marginTop)
            .attr("width", Math.max(0, x.bandwidth() - 1))
            .attr("height", height - marginTop - marginBottom)
            .attr("fill", color);

        tickAdjust = () => {
        };
    }

    svg.append("g")
        .attr("transform", `translate(0,${height - marginBottom})`)
        .call(d3.axisBottom(x)
            .ticks(ticks, typeof tickFormat === "string" ? tickFormat : undefined)
            .tickFormat(typeof tickFormat === "function" ? tickFormat : undefined)
            .tickSize(tickSize)
            .tickValues(tickValues))
        .call(tickAdjust)
        .call(g => g.select(".domain").remove())
        .call(g => g.append("text")
            .attr("x", marginLeft)
            .attr("y", marginTop + marginBottom - height - 6)
            .attr("fill", "currentColor")
            .attr("text-anchor", "start")
            .attr("font-weight", "bold")
            .text(title));

    return svg.node();
}

function ramp(color, n = 256) {
    let canvas = document.createElement('canvas');
    canvas.width = n;
    canvas.height = 1;
    const context = canvas.getContext("2d");
    for (let i = 0; i < n; ++i) {
        context.fillStyle = color(i / (n - 1));
        context.fillRect(i, 0, 1, 1);
    }
    return canvas;
}

function swap(a, p, q) {
    let v = a[p];
    a[p] = a[q];
    a[q] = v;
    return a;
}

function sg_map(sg, map_data) {
    let path = d3.geoPath()
    const max_count = 0.8;
    let color_pap = d3.scaleSequential([0.4, max_count], d3.interpolateReds),
        color_wp = d3.scaleSequential([0.4, max_count], d3.interpolateBlues);

    // Add 2 legends
    let svg = d3.select("#Map-Legend")
        .append('svg')
        .attr("id", "legend-map");

    svg.append("g")
        .attr("color", "white")
        .append(() => legend({
            color: color_pap, title: "PAP", width: 300, height: 70,
            marginLeft: 10, marginRight: 0, tickSize: 8, tickFormat: ".0%"
        }));
    svg.append("g")
        .attr("transform", "translate(0, 70)")
        .attr("color", "white")
        .append(() => legend({
            color: color_wp, title: "WP", width: 300, height: 70,
            marginLeft: 10, marginRight: 0, tickSize: 8, tickFormat: ".0%"
        }));

    // Create the SG Map
    const max_y = sg.bbox[3], min_x = sg.bbox[0], min_y = sg.bbox[1], width = sg.bbox[2] - min_x,
        height = max_y - min_y;
    svg = d3.select("#Map")
        .insert('svg', ':first-child')
        .attr("id", "sg-map")
        .attr("viewBox", [min_x, min_y, width, height]);

    let data = topojson.feature(sg, sg.objects.boundary).features;
    let result;

    svg.append("g")
        .selectAll("path")
        .data(data)
        .join("path")
        .attr('class', 'area')
        .attr("fill", 'white')
        .attr("stroke", "black")
        .attr("stroke-width", "0.1%")
        .attr("stroke-linejoin", "round")
        .attr("d", path)
        .attr('title', d => {
            const item = map_data.get(d.properties.Name);
            let str = `${d.properties.Name} (${item.type})
            ${item['Political Party A']}: ${item['Final Result A']} (votes: ${item['Final Votes A']}, amount spent: S$${item['Amount Spend A']})
            ${item['Political Party B']}: ${item['Final Result B']} (votes: ${item['Final Votes B']}, amount spent: S$${item['Amount Spend B']})`;
            if (item['Political Party C'] !== '') {
                str += `\n${item['Political Party C']}: ${item['Final Result C']} (votes: ${item['Final Votes C']}, amount spent: S$${item['Amount Spend C']})`;
            }
            return str;
        });

    // Transition
    svg = d3.select('#sg-map')
        .selectAll('path')
        .transition()
        .duration(2000)
        .attr("fill", d => {
            result = parseFloat(map_data.get(d.properties.Name)['Final Result A']);
            if (parseFloat(map_data.get(d.properties.Name)['Final Result B']) > result)
                result = parseFloat(map_data.get(d.properties.Name)['Final Result B']);
            result /= 100.0;
            if (map_data.get(d.properties.Name).Winner === 'PAP') {
                return color_pap(result);
            } else {
                return color_wp(result);
            }
        });

    // Hover Listener
    $(".area").hover((event) => {
        $(event.target).attr('stroke', 'white').attr("stroke-width", "0.2%")
            .appendTo($(event.target).parent());

    }, (event) => {
        $(event.target).attr('stroke', 'black').attr("stroke-width", "0.1%")
            .appendTo($(event.target).parent());
    })
}


function create_data_dict(grc, smc) {
    let arr = grc.concat(smc);
    let map_data = new Map();
    let i, name;
    for (i = 0; i < arr.length; i++) {
        if ("GRC" in arr[i]) {
            name = arr[i].GRC;
            delete arr[i].GRC;
            arr[i].type = 'GRC';
        } else {
            name = arr[i].SMC;
            delete arr[i].SMC;
            arr[i].type = 'SMC';
        }
        map_data.set(name.toUpperCase(), arr[i]);
    }

    return map_data;
}


function pie_chart(map_data) {
    const svg = d3.select('#Pie-Container').append('svg')
        .attr('id', 'pie')
    const pie_rect = $('#pie')[0].getBoundingClientRect();
    const width = pie_rect.width, height = pie_rect.height;
    const g = svg.append('g')

    // Generate Expenditure Data
    let data = new Map();
    let k, v, p, m, i;
    for ([k, v] of map_data.entries()) {
        p = [v['Political Party A'], v['Political Party B'], v['Political Party C']];
        m = [v['Amount Spend A'], v['Amount Spend B'], v['Amount Spend C']];
        for (i = 0; i < m.length; i++) {
            m[i] = parseFloat(m[i].replace(',', ''));
        }
        for (i = 0; i < p.length; i++) {
            if (p[i] === '')
                continue;
            if (data.has(p[i])) {
                data.set(p[i], data.get(p[i]) + m[i]);
            } else {
                data.set(p[i], m[i]);
            }
        }
    }

    let arr_data = [], arr_label = [];
    i = 0;
    for ([k, v] of data.entries()) {
        arr_label[i] = k;
        arr_data[i] = v;
        i += 1;
    }

    const radius = Math.min(width, height) / 2;

    let arr_color = d3.schemePaired;

    // PAP as red
    arr_color = swap(arr_color, 1, 5);
    // WP as blue
    arr_color = swap(arr_color, 5, 0);
    let color = d3.scaleOrdinal(arr_color);

    const arc = d3.arc()
        .outerRadius(radius - 10)
        .innerRadius(0);

    const pie = d3.pie();

    const pied_data = pie(arr_data);

    i = 0;
    const arcs = g.selectAll('.arc').data(pied_data).join(
        (enter) => enter.append('path')
            .attr('class', 'arc')
            .attr('title', d => {
                i += 1;
                return `${arr_label[i - 1]}: S$${d.value}`;
            })
            .style('transform', `translate(77vw, 40vh)`)
    );

    arcs.attr('d', arc)
        .style('fill', (d, i) => color(i));


    // Legend
    const legend = svg.append('g')

    const lg = legend.selectAll('g')
        .data(arr_label)
        .enter()
        .append('g')


    lg.append('rect')
        .attr('fill', function (d, i) {
            return color(i);
        })
        .attr('x', 0)
        .attr('y', 0)
        .attr('width', '1em')
        .attr('height', '1em');

    lg.append('text')
        .style('font-size', '1em')
        .attr('x', '1.2em')
        .attr('y', '0.8em')
        .attr("fill", "white")
        .text(function (d) {
            return d;
        })

    let offset = 0;
    lg.style('transform', function (d, i) {
        let x = offset;
        offset += (this.getBBox().height) * 1.5;
        return `translate(91vw, ${x*100/window.outerHeight+22}vh)`;
    });

    // Hover Listener
    $(".arc").hover((event) => {
        $(event.target).attr("stroke-width", "1%").attr("stroke", 'white')
    }, (event) => {
        $(event.target).attr("stroke-width", "0.0%")
    })
}

function stackBar(data, option) {
// append the svg object to the body of the page
    let svg = d3.select("#Stack_GRC_SMC")
        .append("svg")

    const rect = $('#Stack_GRC_SMC svg')[0].getBoundingClientRect();
    const width = rect.width, height = rect.height * 0.8;

    svg
        .attr('width', width)
        .attr('height', height)
        .append("g")

    let parties_GRC = ['WP', 'RP', 'SPP', 'PSP', 'PAP', 'SDP', 'PV', 'RDU', 'SDA', 'NSP']

    let parties_SMC = ["PAP", "SDP", "PSP", "WP", "PPP", "PV", "SPP", "RP", "IND"]

    let parties = option === 'GRC' ? parties_GRC : parties_SMC;

    // Add X axis
    let x = d3.scaleBand()
        .domain(data.map(function (d) {
            return d.group;
        }))
        .range([0, width])
        .padding([0.5])

    svg.append("g")
        .attr("transform", "translate(0," + height + ")")
        .style("font-size", "0.6em")
        .attr("color", "white")
        .call(d3.axisBottom(x).tickSizeOuter(0));

    // Add Y axis
    let y = d3.scaleLinear()
        .domain([0, 5])
        .range([height, 0]);

    svg.append("g")
        .style("font-size", "0.6em")
        .attr("color", "white")
        .call(d3.axisLeft(y));

    // color palette = one color per subgroup

    let arr_color = d3.schemePaired;
    let i_pap, i_wp, i_red, i_blue;

    if (option === 'GRC') {
        i_pap = parties_GRC.findIndex(s => s === 'PAP');
        i_wp = parties_GRC.findIndex(s => s === 'WP');
    } else {
        i_pap = parties_SMC.findIndex(s => s === 'PAP');
        i_wp = parties_SMC.findIndex(s => s === 'WP');
    }
    // PAP as red
    i_red = arr_color.findIndex(c => c === '#e31a1c');
    arr_color = swap(arr_color, i_red, i_pap);
    // WP as blue
    i_blue = arr_color.findIndex(c => c === '#1f78b4');
    arr_color = swap(arr_color, i_blue, i_wp);

    let color = d3.scaleOrdinal(arr_color);
    let stackedData = d3.stack()
        .keys(parties)
        (data)

    // ----------------
    // Create a tooltip
    // ----------------
    let tooltip = d3.select('.tooltip');
    if (tooltip.empty()) {
        tooltip = d3.select("body")
            .insert("div", '#Stack_GRC_SMC')
            .attr("class", "tooltip")
    }


    // Three function that change the tooltip when user hover / move / leave a cell
    let mouseover = function (e) {
        let d = this.__data__;
        let partiesName = d3.select(this.parentNode).datum().key;
        let partiesValue = d.data[partiesName];
        tooltip
            .html("Party: " + partiesName + "<br>" + "Amount Spent(S$): " + partiesValue)
            .style("opacity", 1)
    }
    let mousemove = function (e) {
        tooltip
            .style("left", (e.pageX) + "px")
            .style("top", (e.pageY - 55) + "px")
    }
    let mouseleave = function () {
        tooltip
            .style("opacity", 0)
    }

    let U = svg.selectAll("rect")
        .data(stackedData)

    U
        .enter().append("g")
        .attr("fill", function (d, i) {
            return color(d.key);
        })
        .selectAll("rect")
        .data(function (d) {
            return d;
        })
        .enter().append("rect")
        .attr("x", function (d) {
            return x(d.data.group);
        })
        .attr("y", height)
        .attr("height", 0)
        .attr("width", x.bandwidth())
        .on("mouseover", mouseover)
        .on("mousemove", mousemove)
        .on("mouseleave", mouseleave)
        .merge(U)
        .transition()
        .duration(1700)
        .attr("y", function (d) {
            return y(d[1]);
        })
        .attr("height", function (d) {
            return y(d[0]) - y(d[1]);
        });

    var legend = svg.append('g')
        .attr('class', 'legend')


    legend.selectAll('rect')
        .data(parties)
        .join('rect')
        .attr('x', '0.5em')
        .attr('y', function (d, i) {
            return `${i * 1}em`;
        })
        .attr('width', '0.6em')
        .attr('height', '0.6em')
        .attr('fill', function (d, i) {
            return color(d);
        });

    legend.selectAll('text')
        .data(parties)
        .enter()
        .append('text')
        .text(function (d) {
            return d;
        })
        .style("font-size", "0.6em")
        .style("fill", "white")
        .attr('x', '2.2em')
        .attr('y', function (d, i) {
            return `${0.83 + 1.662 * i}em`;
        })

    // Hover Listener
    $("rect").hover((event) => {
        $(event.target).attr("stroke-width", "2px").attr("stroke", 'white')
    }, (event) => {
        $(event.target).attr("stroke-width", "0")
    })
}


function hChart(data, color) {

    let svg = d3.select("#HBC")
        .append("svg")
        .append("g")

    const rect = $('#HBC svg')[0].getBoundingClientRect() ;
    const width = rect.width, height = rect.height;


    let x = d3.scaleLinear()
        .range([0, width])
    let xAxis = svg.append("g")
        .attr("transform", "translate(0," + height + ")")
        .style("font-size", "1em")
        .style("color", "white")

    let y = d3.scaleBand()
        .range([0, height])
        .padding(0.6);
    let yAxis = svg.append("g")
        .attr("class", "myYaxis")
        .style("font-size", "1em")
        .style("color", "white")

    y.domain(data.map(function (d) {
        return d.group;
    }))
    yAxis.call(d3.axisLeft(y))

    x.domain([0, d3.max(data, function (d) {
        return d.value
    })])
    xAxis.transition().duration(1700).call(d3.axisBottom(x))


    let u = svg.selectAll("rect")
        .data(data)

    u
        .join('rect')
        .attr('class', 'hbc-rect')
        .attr('title', d => `${d.group}: ${d.value}%`)
        .attr("x", x(0))
        .attr("y", function (d) {
            return y(d.group);
        })
        .attr("height", y.bandwidth())
        .attr("fill", color)
        .merge(u)
        .transition()
        .duration(1700)
        .attr("width", function (d) {
            return x(d.value);
        })
}


async function drawChart(option) {
    let dataSource = option === 'GRC' ? 'data/GRC_Expenditure_Individual.csv' : 'data/SMC_exp_per_voter.csv';
    let data = await d3.csv(dataSource);
    stackBar(data, option)
}

async function update(option) {
    // Stacked Bar Chart
    d3.select('#Stack_GRC_SMC').html("")
    drawChart(option)

    // Horizontal Bar Chart
    d3.select('#HBC').html("")
    let color1 = "#4ABEB0"
    let color2 = "#EAC78E"


    let [data, color] = option === 'GRC' ? [await d3.csv("data/GRC_Vote.csv"), color1]
        : [await d3.csv("data/SMC_Vote.csv"), color2];
    hChart(data, color)
}

async function charts() {
    let sg = await d3.json("data/electoral-boundary-dataset.json");
    let grc = await d3.csv("data/GE2020_GRC.csv");
    let smc = await d3.csv('data/GE2020_SMC.csv');

    const map_data = create_data_dict(grc, smc);
    sg_map(sg, map_data);
    pie_chart(map_data);

    // Bar Charts
    update('GRC');
}


// Add JQueryUI - Tooltip
$(function () {
    $(document).tooltip({
        track: true,
        position: {
            my: "center bottom-20",
            at: "center top",
            using: function (position, feedback) {
                $(this).css(position);
                $("<div>")
                    .addClass("arrow")
                    .addClass(feedback.vertical)
                    .addClass(feedback.horizontal)
                    .appendTo(this);
                let class_name = feedback.target.element[0].target.className.baseVal;
                if (class_name === 'arc') {
                    // Mouse over arc element
                    $('.arrow').css('margin-left', '-45px');
                } else if (class_name === 'hbc-rect') {
                    $('.arrow').css('margin-left', '-32px');
                } else {
                    $('.arrow').css('margin-left', '-15px');
                }
            }
        }
    });
    $(".area, .arc").tooltip({
        show: {
            effect: "slideDown",
            // delay: 250
        }
    });
});

// Resize event listener
$( window ).resize(function() {
    location.reload()
});

// Main function
charts()
